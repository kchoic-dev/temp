# __5s Framework Authorization Service__
[Spring Security OAuth][]의 [OAuth 2.0][] 구현을 기반으로 하는 5s Framework 인증 마이크로 서비스입니다. 

5s Framework의 [__비즈니스 마이크로 서비스__][]에 사용자 또는 client application 인증을 제공합니다.

![마이크로 서비스 그림](doc/images/micro_service_component_view_auth_flickering.gif)


##### __목차__
1. [Application 설정](#5s1)
	1. [설치 및 실행 방법](#5s1-1)
	2. [DB Schema 초기 설정](#5s1-2)
	3. [DB 연결 설정](#5s1-3)	
2. [인증(OAuth 2.0 Specification)](#5s2)
	1. [역할자(Role)](#5s2-1)
	2. [인증 방법](#5s2-2)
	3. [인증 방법에 따른 절차](#5s2-3)
	4. [인증 방법에 따른 구현 예제](#5s2-4)	
3. [인증 권한 설정(5s Framework Custom)](#5s3)
	1. [권한(Authority)](#5s3-1)


## <a id="5s1"/>__Application 설정__
### <a id="5s1-1"/>__설치 및 실행 방법__ 
1. git clone으로 local reposiotry 생성
2. Java IDE에서 Maven project로 import
3. Web Application으로 실행

### <a id="5s1-2"/>__DB Schema 초기 설정__ 

Table DDL

[/src/main/resources/oauth2.sql](http://70.121.244.190/gitnsam/fsframework/fsf-auth-svc/blob/master/src/main/resources/oauth2.sql)

Sample Data DML	

[/src/main/resources/oauth2_data.sql](http://70.121.244.190/gitnsam/fsframework/fsf-auth-svc/blob/master/src/main/resources/oauth2_data.sql)

### <a id="5s1-3"/>__DB 연결 설정__
[/src/main/java/com/sds/fsf/auth/config/AppConfig.java](http://70.121.244.190/gitnsam/fsframework/fsf-auth-svc/blob/master/src/main/java/com/sds/fsf/auth/config/AppConfig.java#L45-51)
```java
	@Bean(destroyMethod = "close")
	public DataSource dataSource() {
		
		PGPoolingDataSource dataSource = new PGPoolingDataSource();
		dataSource.setServerName("70.7.41.125");
		dataSource.setDatabaseName("fsf");
		dataSource.setUser("fsfauth");
		dataSource.setPassword("1");
		dataSource.setMaxConnections(5);
		return dataSource;
	}
```

## <a id="5s2"/>__인증(OAuth 2.0 Specification)__
자세한 내용은 [OAuth 2.0][] 참조
### <a id="5s2-1"/>__역할자(Role)__
|역할자              |역할                                                                                                                                                     |
|--------------------|---------------------------------------------------------------------------------------------------------------------------------------------------------|
|Resource Owner      |사람                                                                                                                                                     |
|Client              |Resource를 이용하는 Application, Authorization Grant Type에 따라 Access_token을 발급 받아 Resource를 이용                                                |
|Resource Server     |Resource를 보관하는 Application, Access_token을 체크하기 위해 Authorization Server에 부탁, Authorized된 Client에 Resource를 내어줌                       | 
|Authorization Server|Resource에 접근을 허가하는 Application, 허가된 Authorization Grant Type을 확인하고 Access_toekn을 발급, Resource Server의 요청에 따라 Access_token을 확인|



### <a id="5s2-2"/>__인증 방법__
1. [Password](#password)[(외부 link)](http://tools.ietf.org/html/rfc6749#section-4.3)
2. [Client credentials](#client-credentials)
3. [Authorization code](#cuthorization-code)
4. [Implicit](#implicit)

### <a id="5s2-3"/>__인증 방법에 따른 절차__

#### __Password__
1. AngularJS App이 Auth Svc로부터 access_token 획득을 위한 호출
2. Auth Svc가 AngularJS App에 access_token 반환
3. AngularJS App이 access_token과 함께 Micro Svc 호출
4. Micro Svc는 Auth Svc에 access_token 체크
5. Auth Svc가 Micro Svc에 token 정보 반환
6. Micro Svc가 AngularJS App에 응답
![Password 인증 절차를 설명한 그림](doc/images/auth_password.png)

#### __Client credentials__
1. AngularJS App이 Auth Svc로부터 access_token 획득을 위한 호출
2. Auth Svc가 AngularJS App에 access_token 반환
3. AngularJS App이 access_token과 함께 Micro Svc 호출
4. Micro Svc는 Auth Svc에 access_token 체크
5. Auth Svc가 Micro Svc에 token 정보 반환
6. Micro Svc가 AngularJS App에 응답
![Client credentials 인증 절차를 설명한 그림](doc/images/auth_client_credentials.png)

#### __Authorization code__
1. AngularJS App에서 User-agent를 통해 Auth Svc access_token 획득을 위한 호출
2. Auth Svc가 AngularJS App에 access_token 및 Http Status Code 302 반환, User-agent가 Location 값을 이용하여 AngularJS App 호출 및 code 전달
3. AngularJS App이 전달받은 code값을 이용하여, Auth Svc로부터 access_token 획득을 위한 호출
4. Auth Svc가 AngularJS App에 access_token 반환
5. AngularJS App이 access_token과 함께 Micro Svc 호출
6. Micro Svc는 Auth Svc에 access_token 체크
7. Auth Svc가 Micro Svc에 token 정보 반환
8. Micro Svc가 AngularJS App에 응답
![Authorization code 인증 절차를 설명한 그림](doc/images/auth_authorization_code.png)

#### __Implicit__
1. AngularJS App에서 User-agent를 통해 Auth Svc access_token 획득을 위한 호출
2. Auth Svc가 AngularJS App에 access_token 및 Http Status Code 302 반환, User-agent가 Location 값을 이용하여 AngularJS App 호출 및 access_token 전달
3. AngularJS App이 access_token과 함께 Micro Svc 호출
4. Micro Svc는 Auth Svc에 access_token 체크
5. Auth Svc가 Micro Svc에 token 정보 반환
6. Micro Svc가 AngularJS App에 응답
![Implicit 인증 절차를 설명한 그림](doc/images/auth_implicit.png)


### <a id="5s2-4"/>__인증 방법에 따른 구현 예제__
5s Framework Authorization Service는 AngularJS 기반의 인증 방법에 따른 구현 예제를 함께 포함하고 있다.

#### __소스 코드__
1. [Login View (HTML)](http://70.121.244.190/gitnsam/fsframework/fsf-auth-svc/blob/chs_dev/src/main/webapp/app/modules/account/views/login.view.html)
2. [Login Controller (Javascript)](http://70.121.244.190/gitnsam/fsframework/fsf-auth-svc/blob/chs_dev/src/main/webapp/app/modules/account/controllers/login.controller.js)
3. [Authorization Service (Javascript)](http://70.121.244.190/gitnsam/fsframework/fsf-auth-svc/blob/chs_dev/src/main/webapp/app/common/auth/provider/auth.oauth2.service.js)
4. [Authorization Code Default Redirect URI Page (HTML)](http://70.121.244.190/gitnsam/fsframework/fsf-auth-svc/blob/chs_dev/src/main/webapp/oauth_redirect_code.html)
5. [Implicit Default Redirect URI Page (HTML)](http://70.121.244.190/gitnsam/fsframework/fsf-auth-svc/blob/chs_dev/src/main/webapp/oauth_redirect_token.html)

#### __접속 주소__
>__{ AUTH_SVC_URL } /auth/fsf/#/login?grant_type= \[ *password* | *client_credentials* | *authorization_code* | *implicit* \] ( &redirect_uri= { REDIRECT_URI } )__
>```
>	{ AUTH_SVC_URL } :
>		5s Framework Authorization Service의 URL 주소
>
>	grant_type=[password|client_credentials|authorization_code|implicit] :
>		인증 방법의 종류로 password, client_credentials, authorization_code, implicit 중 택 1.
>
>	(&redirect_uri={ REDIRECT_URI }) :
>		authorization_code, implicit 인증 방법은 인증 후 token 발급을 위한 redirect_uri를 설정해주어야 한다. 생략가능
>
>	cf. password 인증 방법으로 인증하고자 할 때,
>		http://123.123.123.123/auth/fsf/#/login?grant_type=password
>
>	cf. authorization_code 인증 방법으로 인증하고자 할 때, redirect_uri를 지정하지 않을 경우 default 값이 호출  
>		http://123.123.123.123/auth/fsf/#/login?grant_type=password&redirect_url=http://111.111.111.111/redirected  
```

접속하면 다음과 같은 화면을 볼 수 있다.

__password 인증방법 login 화면__ 
![password login sample 그림](doc/images/password_login_sample.png)

__client_credentials 인증방법 login 화면__ 
![client_credentials login sample 그림](doc/images/client_credentials_login_sample.png)

## <a id="5s3"/>__인증 권한 설정(5s Framework Custom)__

위에서 설명한 Spring Security OAuth와 OAuth 2.0은 인증(Authorization)에 대한 Specification이며, 

별도로 인증할 권한(Authority)에 대해 정의하고, 설정하는 내용이 필요합니다.

아래 설명하는 내용은 다음과 같은 내용을 포함합니다.

1. 5s Framework의 권한의 정의
2. 관련된 5s Framework 인증 마이크로 서비스의 기능

### <a id="5s3-1"/>__권한(Authority)__

#### __권한의 부여 :__
```
	권한은 Client Appication 또는 사용자에 부여
```

#### __권한의 형식 :__ 
정규표현식 `"^ROLE(_[A-Z][A-Z0-9]*)+$"`을 만족하는 String 
```
	//Java 표현식으로 권한 myAuthority는 
	myAuthority instanceof String == true
	myAuthority.matches("^ROLE(_[A-Z][A-Z0-9]*)+$") == true
```
하위 권한은 정규표현식 `"^(상위권한)(_[A-Z][A-Z0-9]*)+$"`을 만족
```
	//Java 표현식으로 권한 authorit의 하위 권한 subAuthority 
	subAuthoruty.matches("^" + authority + "(_[A-Z][A-Z0-9]*)+$") == true
```

#### __권한의 계층 :__
```
	상위 권한은 하위 권한을 생성, 삭제, 부여
	상위 권한은 하위 권한을 포함
```

#### __권한의 범위(scope) :__ 
```
	client 범위(scope) 안에서의 user 권한만 유효하다.

	cf. client가 범위 “ROLE_A”, “ROLE_B_BB”. “ROLE_C”, “ROLE_E”를 가지고,
	      user가 권한 “ROLE_A_AA”, “ROLE_B”, “ROLE_C”, “ROLE_D”을 가지면, 
	      user는 권한 “ROLE_A_AA”, “ROLE_C” 만 사용 가능하다.

	cf. client의 권한과 범위는 다른 개념이다.
```
![권한의 범위에 따른 인증의 차이에 대한 그림](doc/images/authorization_difference_based_on_client_scope.png)

[Spring Security OAuth]: http://projects.spring.io/spring-security-oauth/
[OAuth 2.0]: http://oauth.net/2/
[__비즈니스 마이크로 서비스__]: http://70.121.244.190/gitnsam/fsframework/fsf-sample-svc/tree/master
