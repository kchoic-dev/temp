package com.sds.fsf.auth.domain;

import org.hibernate.annotations.Type;
import org.hibernate.envers.Audited;
import org.joda.time.DateTime;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import com.fasterxml.jackson.annotation.JsonIgnore;

import javax.persistence.Column;
import javax.persistence.EntityListeners;
import javax.persistence.MappedSuperclass;
import javax.validation.constraints.NotNull;

/**
 * Base abstract class for entities which will hold definitions for created, last modified by and created,
 * last modified by date.
 */
@MappedSuperclass
@Audited
@EntityListeners(AuditingEntityListener.class)
public abstract class AbstractAuditingEntity {

	@JsonIgnore
    @CreatedBy
    @NotNull
    @Column(name = "create_by_id", nullable = false, length = 50, updatable = false)
    private String createById="Admin";

	@JsonIgnore
    @CreatedDate
    @NotNull
    @Type(type = "org.jadira.usertype.dateandtime.joda.PersistentDateTime")
    @Column(name = "create_dttm", nullable = false)
    private DateTime createDTTM = DateTime.now();

	@JsonIgnore
    @LastModifiedBy
    @NotNull
    @Column(name = "last_update_by_id", length = 50, nullable = false)
    private String lastUpdateById="Admin";

	@JsonIgnore
    @LastModifiedDate
    @NotNull
    @Type(type = "org.jadira.usertype.dateandtime.joda.PersistentDateTime")
    @Column(name = "last_update_dttm", nullable = false)
    private DateTime lastUpdateDttm = DateTime.now();

    
    
	public String getCreateById() {
		return createById;
	}

	public void setCreateById(String createById) {
		this.createById = createById;
	}

	public DateTime getCreateDTTM() {
		return createDTTM;
	}

	public void setCreateDTTM(DateTime createDTTM) {
		this.createDTTM = createDTTM;
	}

	public String getLastUpdateById() {
		return lastUpdateById;
	}

	public void setLastUpdateById(String lastUpdateById) {
		this.lastUpdateById = lastUpdateById;
	}

	public DateTime getLastUpdateDttm() {
		return lastUpdateDttm;
	}

	public void setLastUpdateDttm(DateTime lastUpdateDttm) {
		this.lastUpdateDttm = lastUpdateDttm;
	}

    
}