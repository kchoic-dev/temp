package com.sds.fsf.auth.web.rest.type2.dto;

import java.util.List;

public class Type2UserDTOForResponse extends Type2UserDTOForRegister{

    private List<String> roles;

    public Type2UserDTOForResponse() {
    }

    public Type2UserDTOForResponse(String login, String password,
			String firstName, String lastName, String email,
			String mobilePhoneNumber, String langKey, String authorityBase, List<String> roles) {
		super(login, password, firstName, lastName, email, mobilePhoneNumber, langKey, authorityBase);
		this.roles = roles;
	}
    
	public List<String> getRoles() {
		return roles;
	}

	@Override
	public String toString() {
		return "Type2UserDTOForResponse [roles=" + roles + ", getPassword()="
				+ getPassword() + ", getLogin()=" + getLogin()
				+ ", getFirstName()=" + getFirstName() + ", getLastName()="
				+ getLastName() + ", getEmail()=" + getEmail()
				+ ", getMobilePhoneNumber()=" + getMobilePhoneNumber()
				+ ", getLangKey()=" + getLangKey() + "]";
	}

    

}
