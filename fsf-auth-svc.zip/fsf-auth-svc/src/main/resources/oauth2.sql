create table oauth_client_details (
  client_id VARCHAR(256) PRIMARY KEY,
  resource_ids VARCHAR(256),
  client_secret VARCHAR(256),
  scope VARCHAR(256),
  authorized_grant_types VARCHAR(256),
  web_server_redirect_uri VARCHAR(256),
  authorities VARCHAR(256),
  access_token_validity INTEGER,
  refresh_token_validity INTEGER,
  additional_information VARCHAR(4096),
  autoapprove VARCHAR(256)
)
WITH (
  OIDS=FALSE
);

create table oauth_client_token (
  token_id VARCHAR(256),
  token bytea,
  authentication_id VARCHAR(256) PRIMARY KEY,
  user_name VARCHAR(256),
  client_id VARCHAR(256)
)
WITH (
  OIDS=FALSE
);

create table oauth_access_token (
  token_id VARCHAR(256),
  token bytea,
  authentication_id VARCHAR(256) PRIMARY KEY,
  user_name VARCHAR(256),
  client_id VARCHAR(256),
  authentication bytea,
  refresh_token VARCHAR(256)
)
WITH (
  OIDS=FALSE
);

create table oauth_refresh_token (
  token_id VARCHAR(256),
  token bytea,
  authentication bytea
)
WITH (
  OIDS=FALSE
);

create table oauth_code (
  code VARCHAR(256), authentication bytea
)
WITH (
  OIDS=FALSE
);

create table oauth_approvals (
	userId VARCHAR(256),
	clientId VARCHAR(256),
	scope VARCHAR(256),
	status VARCHAR(10),
	expiresAt TIMESTAMP,
	lastModifiedAt TIMESTAMP
)
WITH (
  OIDS=FALSE
);

CREATE TABLE fsf_user
(
  id bigint NOT NULL,
  login character varying(50) NOT NULL,
  password character varying(100) NOT NULL,
  first_name character varying(50),
  last_name character varying(50),
  email character varying(100),
  activated boolean NOT NULL,  
  activation_key character varying(20),
  lang_key character varying(5),
  mobile_phone_number character varying(100),
  authority_base character varying(50),  
  create_by_id character varying(50) NOT NULL,
  create_dttm timestamp without time zone NOT NULL,
  last_update_by_id character varying(50) NOT NULL,
  last_update_dttm timestamp without time zone NOT NULL,
  CONSTRAINT pk_fsf_user PRIMARY KEY (id),
  CONSTRAINT fsf_user_email_key UNIQUE (email),
  CONSTRAINT fsf_user_login_key UNIQUE (login)
)
WITH (
  OIDS=FALSE
);

CREATE TABLE fsf_authority
(
  name character varying(50) NOT NULL,
  CONSTRAINT pk_fsf_authority PRIMARY KEY (name)
)
WITH (
  OIDS=FALSE
);

CREATE TABLE fsf_user_authority
(
  user_id bigint NOT NULL,
  authority_name character varying(50) NOT NULL,
  CONSTRAINT pk_fsf_user_authority PRIMARY KEY (user_id, authority_name),
  CONSTRAINT fk_authority_name FOREIGN KEY (authority_name)
      REFERENCES fsf_authority (name) MATCH SIMPLE
      ON UPDATE NO ACTION ON DELETE NO ACTION,
  CONSTRAINT fk_user_id FOREIGN KEY (user_id)
      REFERENCES fsf_user (id) MATCH SIMPLE
      ON UPDATE NO ACTION ON DELETE NO ACTION
)
WITH (
  OIDS=FALSE
);

CREATE TABLE fsf_client_grant_default_user_authority
(
  client_id character varying(255) NOT NULL,
  authority_id character varying(50) NOT NULL,
  CONSTRAINT pk_fsf_client_grant_default_user_authority PRIMARY KEY (client_id, authority_id),
  CONSTRAINT fk_client_id FOREIGN KEY (client_id)
      REFERENCES oauth_client_details (client_id) MATCH SIMPLE
      ON UPDATE NO ACTION ON DELETE NO ACTION,
  CONSTRAINT fk_authority_id FOREIGN KEY (authority_id)
      REFERENCES fsf_authority (name) MATCH SIMPLE
      ON UPDATE NO ACTION ON DELETE NO ACTION
)
WITH (
  OIDS=FALSE
);