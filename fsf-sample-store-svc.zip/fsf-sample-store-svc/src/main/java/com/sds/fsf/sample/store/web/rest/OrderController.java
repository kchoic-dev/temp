package com.sds.fsf.sample.store.web.rest;

import java.net.URI;
import java.net.URISyntaxException;

import javax.inject.Inject;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.sds.fsf.sample.store.config.Constants;
import com.sds.fsf.sample.store.domain.Order;
import com.sds.fsf.sample.store.domain.code.OrderStatus;
import com.sds.fsf.sample.store.domain.specification.OrderSearch;
import com.sds.fsf.sample.store.repository.OrderRepository;
import com.sds.fsf.sample.store.service.OrderService;
import com.sds.fsf.sample.store.web.rest.dto.OrderDto;

/**
 * REST controller for managing Order.
 */
@RestController
@RequestMapping("/api")
public class OrderController {

    private final Logger log = LoggerFactory.getLogger(OrderController.class);

    @Inject
    private OrderRepository orderRepository;

    @Inject
    private OrderService orderService;
    
    /**
     * POST  /orders -> Create a new order.
     */
    @RequestMapping(value = "/orders",
            method = RequestMethod.POST,
            produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Order> create(@RequestBody OrderDto.Create dto) throws URISyntaxException {
        log.debug("REST request to save Order : {}", dto);

        Order order = orderService.createOrder(dto.getMemberId(), dto.getItemId(), dto.getCount());
        
        return ResponseEntity.created(new URI("/api/orders/" + order.getId()))
                //.headers(HeaderUtil.createEntityCreationAlert("order", result.getId().toString()))
                .body(order);
    }

    /**
     * POST  /orders/{orderId}/cancel -> Cancel an existing order.
     */
    @RequestMapping(value = "/orders/{orderId}/cancel",
        method = RequestMethod.POST,
        produces = MediaType.APPLICATION_JSON_VALUE)

    public void update(@PathVariable("orderId") Long orderId) throws URISyntaxException {
          	
    	orderService.cancelOrder(orderId);    	
        
    }

    /**
     * GET  /orders -> get all the orders.
     */
    @RequestMapping(value = "/orders",
            method = RequestMethod.GET,
            produces = MediaType.APPLICATION_JSON_VALUE)

    public ResponseEntity<Page<Order>> getAll(
    		@PageableDefault(size = Constants.DEFAULT_RETURN_RECORD_COUNT, page = 0) Pageable pageable,
    		@RequestParam(value= "memberName", required = false) String memberName,
    		@RequestParam(value= "orderStatus", required = false) OrderStatus orderStatus
            ) {

    	OrderSearch orderSearch = new OrderSearch();
    	orderSearch.setMemberName(memberName);
    	orderSearch.setOrderStatus(orderStatus);
    	
    	log.debug("REST request to get all Orders");
    	
    	Page<Order> page = orderService.findOrders(orderSearch, pageable);    	
    	return new ResponseEntity<Page<Order>>(page, HttpStatus.OK);
    }


    
    /**
     * GET  /orders/:id -> get the "id" order.
     */
    @RequestMapping(value = "/orders/{id}",
            method = RequestMethod.GET,
            produces = MediaType.APPLICATION_JSON_VALUE)

    public ResponseEntity<Order> get(@PathVariable Long id, HttpServletResponse response) {
        log.debug("REST request to get Order : {}", id);
        Order order = orderRepository.findOne(id);
        if (order == null) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
        return new ResponseEntity<>(order, HttpStatus.OK);
    }


}
