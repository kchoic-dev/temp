package com.sds.fsf.sample.store.config;

import java.util.Arrays;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.Map;

import javax.inject.Inject;
import javax.servlet.DispatcherType;
import javax.servlet.FilterRegistration;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.ServletRegistration;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.context.embedded.ServletContextInitializer;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;

/**
 * Configuration of web application with Servlet 3.0 APIs.
 */
@Configuration

public class WebConfigurer extends WebMvcConfigurerAdapter implements ServletContextInitializer {

    private final Logger log = LoggerFactory.getLogger(WebConfigurer.class);

    @Inject
    private Environment env;


    @Override
    public void onStartup(ServletContext servletContext) throws ServletException {
        log.info("Web application configuration, using profiles: {}", Arrays.toString(env.getActiveProfiles()));
        
        EnumSet<DispatcherType> disps = EnumSet.of(DispatcherType.REQUEST, DispatcherType.FORWARD, DispatcherType.ASYNC);

        initRequestInfoFilter(servletContext, disps);
        if (env.acceptsProfiles("boot")) {
            initH2Console(servletContext);
        }

    }

	@Override
	public void addCorsMappings(CorsRegistry registry) {
		registry.addMapping("/**")
			.allowedOrigins("*")
			.allowedMethods("GET", "POST", "PUT", "DELETE")
			.allowedHeaders("Authorization","Accept")
			//.exposedHeaders("link")
			.allowCredentials(false).maxAge(3600);
	}
	
    //response.setHeader("Access-Control-Allow-Origin", "*");
    //response.setHeader("Access-Control-Allow-Methods", "POST, GET, DELETE, PUT, OPTIONS");
    //response.setHeader("Access-Control-Max-Age", "3600");
    ///response.setHeader("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept, Authorization, link");  
    //response.setHeader("Access-Control-Expose-Headers", "link");    
    /**
     * Initializes the CORS filter.
     */
    private void initRequestInfoFilter(ServletContext servletContext, EnumSet<DispatcherType> disps) {
        log.debug("Registering MDC Request Info Filter");
        FilterRegistration.Dynamic requestInfoFilter = servletContext.addFilter("requestInfoFilter", new RequestInfoFilter());
        Map<String, String> parameters = new HashMap<>();
        requestInfoFilter.setInitParameters(parameters);
        requestInfoFilter.addMappingForUrlPatterns(disps, true, "*");
        requestInfoFilter.setAsyncSupported(true);
    }
    

    /**
     * Initializes H2 console
     */
    private void initH2Console(ServletContext servletContext) {
        log.debug("Initialize H2 console");
        ServletRegistration.Dynamic h2ConsoleServlet = servletContext.addServlet("H2Console", new org.h2.server.web.WebServlet());
        h2ConsoleServlet.addMapping("/console/*");
        h2ConsoleServlet.setInitParameter("-properties", "src/main/resources");
        h2ConsoleServlet.setLoadOnStartup(1);
    }
}
