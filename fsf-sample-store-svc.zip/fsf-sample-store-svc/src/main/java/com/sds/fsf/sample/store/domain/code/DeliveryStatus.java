package com.sds.fsf.sample.store.domain.code;

/**
 * DeliveryStatus ENUM
 */
public enum DeliveryStatus {
    READY, COMP
}
