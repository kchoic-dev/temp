package com.sds.fsf.sample.store.web.rest;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.sds.fsf.sample.store.domain.Category;
import com.sds.fsf.sample.store.domain.item.Item;
import com.sds.fsf.sample.store.repository.CategoryRepository;

/**
 * REST controller for managing Departement.
 */
@RestController
@RequestMapping("/api")
public class CategoryController {

    private final Logger log = LoggerFactory.getLogger(CategoryController.class);

    
    @Inject
    private CategoryRepository categoryRepository;

    /**
     * POST  /categories -> Create a new category.
     */
    @RequestMapping(value = "/categories",
            method = RequestMethod.POST,
            produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Category> create(@RequestBody Category category) throws URISyntaxException {
        log.debug("REST request to save category : {}", category);
        if (category.getId() != null) {
            return ResponseEntity.badRequest().header("Failure", "A new category cannot already have an ID").body(null);
        }
        Category result = categoryRepository.save(category);
        return ResponseEntity.created(new URI("/api/categories/" + result.getId()))
                .body(result);
    }

    /**
     * PUT  /categories -> Updates an existing categories.
     */
    @RequestMapping(value = "/categories",
        method = RequestMethod.PUT,
        produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Category> update(@RequestBody Category category) throws URISyntaxException {
        log.debug("REST request to update category : {}", category);
        if (category.getId() == null) {
            return create(category);
        }
        Category result = categoryRepository.save(category);
        return ResponseEntity.ok()
                .body(result);
    }

    /**
     * GET  /categories -> get all the categories.
     */
    @RequestMapping(value = "/categories",
            method = RequestMethod.GET,
            produces = MediaType.APPLICATION_JSON_VALUE)
    @PreAuthorize("hasRole('ROLE_ADMIN')")
    public List<Category> getAll(@RequestParam(required = false) String filter) {
        if ("parent-is-null".equals(filter)) {
            log.debug("REST request to get all Categories where parent is null");
            List<Category> categories = new ArrayList<Category>();
            for (Category category : categoryRepository.findAll()) {
                if (category.getParent() == null) {
                	categories.add(category);
                }
            }
            return categories;
        }    	
        log.debug("REST request to get all Departements");
        return categoryRepository.findAll();
    }

    /**
     * GET  /categories/:id -> get the "id" category.
     */
    @RequestMapping(value = "/categories/{id}",
            method = RequestMethod.GET,
            produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Category> get(@PathVariable Long id, HttpServletResponse response) {
        log.debug("REST request to get Departement : {}", id);
        Category category = categoryRepository.findOne(id);
        if (category == null) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
        return new ResponseEntity<>(category, HttpStatus.OK);
    }

    /**
     * DELETE  /categories/:id -> delete the "id" category.
     */
    @RequestMapping(value = "/categories/{id}",
            method = RequestMethod.DELETE,
            produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        log.debug("REST request to delete Departement : {}", id);
        categoryRepository.delete(id);
        return ResponseEntity.ok()
        		.build();
    }
    
    
    /**
     * GET  /categories/{id}/items -> get the "id" category's items.
     */
    @RequestMapping(value = "/categories/{id}/items",
            method = RequestMethod.GET,
            produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<List<Item>> getItems(@PathVariable Long id, HttpServletResponse response) {
        log.debug("REST request to get Items for categoryId : {}", id);
        
        Category category = categoryRepository.findOne(id);
        List<Item> items = category.getItems();
        if (items == null) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
        return new ResponseEntity<>(items, HttpStatus.OK);
    }    

    /**
     * GET  /categories/{id}/items -> get the "id" category's items.
     */
    @RequestMapping(value = "/categories/{id}/child",
            method = RequestMethod.GET,
            produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<List<Category>> getChild(@PathVariable Long id, HttpServletResponse response) {
        log.debug("REST request to get Items for categoryId : {}", id);
        
        Category category = categoryRepository.findOne(id);
        List<Category> categories = category.getChild();
        if (categories == null) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
        return new ResponseEntity<>(categories, HttpStatus.OK);
    }

    
}
