package com.sds.fsf.sample.store.web.rest;

import java.net.URI;
import java.net.URISyntaxException;

import javax.inject.Inject;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.sds.fsf.sample.store.config.Constants;
import com.sds.fsf.sample.store.domain.Member;
import com.sds.fsf.sample.store.repository.MemberRepository;

import ch.qos.logback.core.net.SyslogOutputStream;

/**
 * REST controller for managing Member.
 */
@RestController
@RequestMapping("/api")
public class MemberController {

    private final Logger log = LoggerFactory.getLogger(MemberController.class);

    @Inject
    private MemberRepository memberRepository;

    /**
     * POST  /members -> Create a new member.
     */
    @RequestMapping(value = "/members",
            method = RequestMethod.POST,
            produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Member> create(@RequestBody Member member) throws URISyntaxException {
        log.debug("REST request to save Member : {}", member);
        if (member.getId() != null) {
            return ResponseEntity.badRequest().header("Failure", "A new member cannot already have an ID").body(null);
        }
        Member result = memberRepository.save(member);
        return ResponseEntity.created(new URI("/api/members/" + result.getId()))
                //.headers(HeaderUtil.createEntityCreationAlert("member", result.getId().toString()))
                .body(result);
    }

    /**
     * PUT  /members -> Updates an existing member.
     */
    @RequestMapping(value = "/members",
        method = RequestMethod.PUT,
        produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Member> update(@RequestBody Member member) throws URISyntaxException {
        log.debug("REST request to update Member : {}", member);
        if (member.getId() == null) {
            return create(member);
        }
        Member result = memberRepository.save(member);
        return ResponseEntity.ok()
                //.headers(HeaderUtil.createEntityUpdateAlert("member", member.getId().toString()))
                .body(result);
    }

    /**
     * GET  /members -> get all the members.
     */
    @RequestMapping(value = "/members",
            method = RequestMethod.GET,
            produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Page<Member>> getAll(
    		@PageableDefault(size = Constants.DEFAULT_RETURN_RECORD_COUNT, page = 0) Pageable pageable,
            @RequestParam(value = "memberName", required = false) String memberName) {
    	
        log.debug("REST request to get all Members");

        Page<Member> page;
        
        System.out.println(pageable);
        
        if (StringUtils.isEmpty(memberName)){
        	page = memberRepository.findAll(pageable);
        }else {
        	String searchCondition = "%"+memberName+"%";
        	page = memberRepository.findByNameLike(searchCondition,pageable);
        }       
        System.out.println(page);
        return new ResponseEntity<Page<Member>>(page, HttpStatus.OK);
    }

    /**
     * GET  /members/:id -> get the "id" member.
     */
    @RequestMapping(value = "/members/{id}",
            method = RequestMethod.GET,
            produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Member> get(@PathVariable Long id, HttpServletResponse response) {
        log.debug("REST request to get Member : {}", id);
        Member member = memberRepository.findOne(id);
        if (member == null) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
        return new ResponseEntity<>(member, HttpStatus.OK);
    }

    /**
     * DELETE  /members/:id -> delete the "id" member.
     */
    @RequestMapping(value = "/members/{id}",
            method = RequestMethod.DELETE,
            produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        log.debug("REST request to delete Member : {}", id);
        memberRepository.delete(id);
        return ResponseEntity.ok()
        		//.headers(HeaderUtil.createEntityDeletionAlert("member", id.toString()))
        		.build();
    }
}
