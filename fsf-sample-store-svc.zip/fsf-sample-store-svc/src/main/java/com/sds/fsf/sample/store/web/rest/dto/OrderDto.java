package com.sds.fsf.sample.store.web.rest.dto;

import javax.validation.constraints.NotNull;

public class OrderDto {


	public static class Create {
	    @NotNull
	    private Long memberId;

		@NotNull
	    private Long itemId;

	    @NotNull
	    private int count;	


		public Long getMemberId() {
			return memberId;
		}

		public void setMemberId(Long memberId) {
			this.memberId = memberId;
		}

		public Long getItemId() {
			return itemId;
		}

		public void setItemId(Long itemId) {
			this.itemId = itemId;
		}

		public int getCount() {
			return count;
		}

		public void setCount(int count) {
			this.count = count;
		}
	}
	
}
