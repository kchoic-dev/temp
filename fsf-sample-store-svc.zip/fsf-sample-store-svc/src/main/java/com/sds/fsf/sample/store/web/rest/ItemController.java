package com.sds.fsf.sample.store.web.rest;

import java.net.URI;
import java.net.URISyntaxException;

import javax.inject.Inject;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.sds.fsf.sample.store.config.Constants;
import com.sds.fsf.sample.store.domain.item.Item;
import com.sds.fsf.sample.store.repository.ItemRepository;

/**
 * REST controller for managing Departement.
 */
@RestController
@RequestMapping("/api")
public class ItemController {

    private final Logger log = LoggerFactory.getLogger(ItemController.class);

    
    @Inject
    private ItemRepository itemRepository;

    /**
     * POST  /items -> Create a new item.
     */
    @RequestMapping(value = "/items",
            method = RequestMethod.POST,
            produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Item> create(@RequestBody Item item) throws URISyntaxException {
        log.debug("REST request to save item : {}", item);
        if (item.getId() != null) {
            return ResponseEntity.badRequest().header("Failure", "A new item cannot already have an ID").body(null);
        }
        Item result = itemRepository.save(item);
        return ResponseEntity.created(new URI("/api/items/" + result.getId()))
                .body(result);
    }

    /**
     * PUT  /items -> Updates an existing items.
     */
    @RequestMapping(value = "/items",
        method = RequestMethod.PUT,
        produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Item> update(@RequestBody Item item) throws URISyntaxException {
        log.debug("REST request to update item : {}", item);
        if (item.getId() == null) {
            return create(item);
        }
        Item result = itemRepository.save(item);
        return ResponseEntity.ok()
                .body(result);
    }

    /**
     * GET  /items -> get all the items.
     */
    @RequestMapping(value = "/items",
            method = RequestMethod.GET,
            produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Page<Item>> getAll(
    		@PageableDefault(size = Constants.DEFAULT_RETURN_RECORD_COUNT, page = 0) Pageable pageable
    		) {
    	
        log.debug("REST request to get all Departements");
        Page<Item> page = itemRepository.findAll(pageable);
        return new ResponseEntity<Page<Item>>(page, HttpStatus.OK);
    }

    /**
     * GET  /items/search/?q=findByNameLike -> get all the books which has title like "id".
     */
    @RequestMapping(value = "/items", params="q=findByNameLike", 
    		method = RequestMethod.GET, 
    		produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Page<Item>> findByNameLike( 
    		@PageableDefault(size = Constants.DEFAULT_RETURN_RECORD_COUNT, page = 0) Pageable pageable,
    		@RequestParam(value = "name" , required = false) String name)
        {
    	
    	String searchCondition = "%"+name+"%";
    	Page<Item> page = itemRepository.findByNameLike(searchCondition, pageable);

        log.debug("REST request find items query findByNamelike: {}", name);
        return new ResponseEntity<Page<Item>>(page, HttpStatus.OK);
        
    }
    
    /**
     * GET  /items/:id -> get the "id" item.
     */
    @RequestMapping(value = "/items/{id}",
            method = RequestMethod.GET,
            produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Item> get(@PathVariable Long id, HttpServletResponse response) {
        log.debug("REST request to get Departement : {}", id);
        Item item = itemRepository.findOne(id);
        if (item == null) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
        return new ResponseEntity<>(item, HttpStatus.OK);
    }

    /**
     * DELETE  /items/:id -> delete the "id" item.
     */
    @RequestMapping(value = "/items/{id}",
            method = RequestMethod.DELETE,
            produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        log.debug("REST request to delete Departement : {}", id);
        itemRepository.delete(id);
        return ResponseEntity.ok()
        		.build();
    }
}
