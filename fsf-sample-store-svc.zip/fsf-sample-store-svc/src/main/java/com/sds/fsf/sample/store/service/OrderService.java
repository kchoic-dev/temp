package com.sds.fsf.sample.store.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.sds.fsf.sample.store.domain.Delivery;
import com.sds.fsf.sample.store.domain.Member;
import com.sds.fsf.sample.store.domain.Order;
import com.sds.fsf.sample.store.domain.OrderItem;
import com.sds.fsf.sample.store.domain.item.Item;
import com.sds.fsf.sample.store.domain.specification.OrderSearch;
import com.sds.fsf.sample.store.repository.ItemRepository;
import com.sds.fsf.sample.store.repository.MemberRepository;
import com.sds.fsf.sample.store.repository.OrderRepository;

/**
 * Created by holyeye on 2014. 3. 12..
 */

@Service
@Transactional
public class OrderService {

    @Autowired MemberRepository memberRepository;
    @Autowired OrderRepository orderRepository;
    @Autowired ItemRepository itemRepository;

    /**
     * 주문
     */
    public Order createOrder(Long memberId, Long itemId, int count) {

        //엔티티 조회
        Member member = memberRepository.findOne(memberId);
        Item item = itemRepository.findOne(itemId);

        //배송정보 생성
        Delivery delivery = new Delivery(member.getAddress());
        //주문상품 생성
        OrderItem orderItem = OrderItem.createOrderItem(item, item.getPrice(), count);
        //주문 생성
        Order order = Order.createOrder(member, delivery, orderItem);

        //주문 저장
        return orderRepository.save(order);
    }


    /**
     * 주문 취소
     */
    public void cancelOrder(Long orderId) {

        //주문 엔티티 조회
        Order order = orderRepository.findOne(orderId);

        //주문 취소
        order.cancel();
    }

    /**
     * 주문 검색
     */
    public Page<Order> findOrders(OrderSearch orderSearch, Pageable pageable) {
    	return orderRepository.findAll(orderSearch.toSpecification(),pageable); // Specification 사용
    	//return orderRepository.search(orderSearch);  //QueryDSL 사용
    }

}
