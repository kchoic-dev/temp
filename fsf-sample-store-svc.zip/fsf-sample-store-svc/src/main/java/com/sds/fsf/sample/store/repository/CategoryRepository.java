package com.sds.fsf.sample.store.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sds.fsf.sample.store.domain.Category;
import com.sds.fsf.sample.store.domain.Member;

/**
 * User: HolyEyE
 * Date: 2013. 12. 3. Time: 오후 9:48
 */
public interface CategoryRepository extends JpaRepository<Category, Long> {
	
	List<Category> findByParent(Category parentCategory);
	
	

}
