package com.sds.fsf.sample.store.domain.code;

/**
 * Created by holyeye on 2014. 3. 11..
 */
public enum OrderStatus {

    ORDER, CANCEL

}
