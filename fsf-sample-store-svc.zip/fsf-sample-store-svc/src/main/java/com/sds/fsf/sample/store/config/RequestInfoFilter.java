package com.sds.fsf.sample.store.config;


import java.io.IOException;
import java.security.Principal;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;

import org.slf4j.MDC;


public class RequestInfoFilter implements Filter {

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
        // Nothing to initialize
    }

    @Override
    public void destroy() {
        // Nothing to destroy
    }

    @Override
    public void doFilter(ServletRequest req, ServletResponse res, FilterChain chain) throws IOException, ServletException {
        
    	String serverName = req.getServerName(); 		// Server Name
    	long threadId = Thread.currentThread().getId();	// ThreadID
    	long now = System.currentTimeMillis();			// Current Time(msec)    	
    	
    	String tid = serverName+"_"+ String.valueOf(now) +"_"+ String.valueOf(threadId); // Transaction ID
    	
    	String userName = "null";
    	
    	HttpServletRequest request = (HttpServletRequest) req; 
    	Principal principal = request.getUserPrincipal();
    	
    	if (principal != null) {
    		userName = principal.getName();
    	}

    	MDC.put("tid", tid);
    	MDC.put("userName", userName);
    	
    	try {
            chain.doFilter(req, res);
        } finally {
            MDC.clear();
        }
    }
	
}
