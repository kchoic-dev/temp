package com.sds.fsf.sample.store.service;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sds.fsf.sample.store.domain.Address;
import com.sds.fsf.sample.store.domain.Category;
import com.sds.fsf.sample.store.domain.Member;
import com.sds.fsf.sample.store.domain.item.Book;
import com.sds.fsf.sample.store.repository.CategoryRepository;
import com.sds.fsf.sample.store.repository.ItemRepository;
import com.sds.fsf.sample.store.repository.MemberRepository;

/**
 * User: HolyEyE
 * Date: 2013. 12. 4. Time: 오후 10:51
 */
@Service
public class MockCreateService {

    @Autowired MemberRepository memberRepository;
    @Autowired ItemRepository itemRepository;
    @Autowired CategoryRepository categoryRepository;
    @Autowired OrderService orderService;

    @PostConstruct
    public void initCreateMock() {   	

    	
    	Category category1 = new Category();
    	category1.setName("NonFiction");

    	Category categoryt = new Category();
    	categoryt.setName("Technology");

    	Category category2 = new Category();
    	category2.setName("Fiction");
    	//categoryRepository.save(category2);

    	Category category3 = new Category();
    	category3.setName("Child");
    	//categoryRepository.save(category3);
    	
    	
    	Category category = new Category();
    	category.setName("Books");
    	
    	category.addChildCategory(category1);
    	category.addChildCategory(category2);
    	category.addChildCategory(category3);
    	
    	category1.addChildCategory(categoryt);
    	
    	
    	
    	
    	categoryRepository.save(category);
    	categoryRepository.save(category1);
    	categoryRepository.save(category2);
    	categoryRepository.save(category3);
    	categoryRepository.save(categoryt);
    	

    	Category category4 = new Category();
    	category4.setName("Classic");
    	

    	Category category5 = new Category();
    	category5.setName("Pop");
    	//categoryRepository.save(category2);

    	Category category6 = new Category();
    	category6.setName("K-Pop");
    	//categoryRepository.save(category3);    	
    	
    	Category categorya = new Category();
    	categorya.setName("Album");    	

    	categorya.addChildCategory(category4);
    	categorya.addChildCategory(category5);
    	categorya.addChildCategory(category6);

    	Category categoryb = new Category();
    	categoryb.setName("Movie"); 
    	

    	categoryRepository.save(categorya);
    	categoryRepository.save(categoryb);
    	categoryRepository.save(category4);
    	categoryRepository.save(category5);
    	categoryRepository.save(category6);    	
    	
    	List<Category> categories1 = new ArrayList<Category>();
    	categories1.add(category2);
    	categories1.add(category3);
    	
    	
    	List<Category> categories2 = new ArrayList<Category>();
    	categories2.add(category1);

    	
    	
    	

        Member member = new Member();
        member.setName("김서울");
        member.setAddress(new Address("서울", "강가", "123-123"));
        
        Member member2 = new Member();
        member2.setName("최경기");
        member2.setAddress(new Address("경기", "강가", "123-123"));        

        Member member3 = new Member();
        member3.setName("박경남");
        member3.setAddress(new Address("경남", "강가", "123-123")); 
        
        Member member4 = new Member();
        member4.setName("John");
        member4.setAddress(new Address("강원", "강가", "123-123")); 
        
        Member member5 = new Member();
        member5.setName("강전북");
        member5.setAddress(new Address("전북", "강가", "123-123")); 
        
        Member member6 = new Member();
        member6.setName("우전남");
        member6.setAddress(new Address("전남", "강가", "123-123")); 
        
        Member member7 = new Member();
        member7.setName("박함북");
        member7.setAddress(new Address("함북", "강가", "123-123")); 
        
        Member member8 = new Member();
        member8.setName("Chris");
        member8.setAddress(new Address("평양", "강가", "123-123")); 

        Member member9 = new Member();
        member9.setName("Sam");
        member9.setAddress(new Address("부산", "강가", "123-123")); 
        
        Member member10 = new Member();
        member10.setName("Whoami");
        member10.setAddress(new Address("대구", "강가", "123-123")); 
        
        
        memberRepository.save(member);
        memberRepository.save(member2);
        memberRepository.save(member3);
        memberRepository.save(member4);
        memberRepository.save(member5);
        memberRepository.save(member6);
        memberRepository.save(member7);
        memberRepository.save(member8);
        memberRepository.save(member9);
        memberRepository.save(member10);
        
        

        Book book = createBook("시골개발자의 JPA 책", 20000, 10);
        book.setCategories(categories2);
        
        Book book2 = createBook("해리포터", 20000, 10);
        book.setCategories(categories1);
        
        itemRepository.save(book);
        itemRepository.save(book2);
        //itemRepository.save(createBook("토비의 봄", 40000, 20));
        
        itemRepository.save(createBook("아리랑1", 40000, 20));
        itemRepository.save(createBook("아리랑2", 40000, 19));
        itemRepository.save(createBook("아리랑3", 40000, 10));
        itemRepository.save(createBook("아리랑4", 40000, 5));
        itemRepository.save(createBook("아리랑5", 40000, 6));
        itemRepository.save(createBook("아리랑6", 40000, 23));
        itemRepository.save(createBook("아리랑7", 40000, 22));
        itemRepository.save(createBook("아리랑8", 40000, 6));
        itemRepository.save(createBook("아리랑9", 40000, 15));
        itemRepository.save(createBook("아리랑10", 40000, 18));
        itemRepository.save(createBook("아리랑11", 40000, 38));
        itemRepository.save(createBook("아리랑12", 40000, 37));
        itemRepository.save(createBook("아리랑13", 40000, 39));
        itemRepository.save(createBook("아리랑14", 40000, 43));
        itemRepository.save(createBook("아리랑15", 40000, 78));
        itemRepository.save(createBook("아리랑16", 40000, 53));
        itemRepository.save(createBook("아리랑17", 40000, 42));
        itemRepository.save(createBook("아리랑18", 40000, 62));
        itemRepository.save(createBook("아리랑19", 40000, 44));
        itemRepository.save(createBook("아리랑20", 40000, 33));
        itemRepository.save(createBook("아리랑21", 40000, 25));
        itemRepository.save(createBook("아리랑22", 40000, 15));
        itemRepository.save(createBook("아리랑23", 40000, 76));
        
        itemRepository.save(createBook("태백산맥1", 60000, 98));
        itemRepository.save(createBook("태백산맥2", 60000, 24));
        itemRepository.save(createBook("태백산맥3", 60000, 88));
        itemRepository.save(createBook("태백산맥4", 60000, 32));
        itemRepository.save(createBook("태백산맥5", 60000, 62));
        itemRepository.save(createBook("태백산맥6", 60000, 45));
        itemRepository.save(createBook("태백산맥7", 60000, 98));
        itemRepository.save(createBook("태백산맥8", 60000, 87));
        itemRepository.save(createBook("태백산맥9", 60000, 54));
        itemRepository.save(createBook("태백산맥10", 60000, 100));
        itemRepository.save(createBook("태백산맥11", 60000, 53));
        itemRepository.save(createBook("태백산맥12", 60000, 63));
        itemRepository.save(createBook("태백산맥13", 60000, 26));
        itemRepository.save(createBook("태백산맥14", 60000, 75));
        itemRepository.save(createBook("태백산맥15", 60000, 98));


        orderService.createOrder(member.getId(), book.getId(), 5);
        orderService.createOrder(member2.getId(), book2.getId(), 4);
        orderService.createOrder(member3.getId(), book.getId(), 6);
        orderService.createOrder(member4.getId(), book2.getId(), 8);
        orderService.createOrder(member5.getId(), book.getId(), 9);
        orderService.createOrder(member6.getId(), book2.getId(), 1);
        orderService.createOrder(member7.getId(), book.getId(), 2);
        orderService.createOrder(member8.getId(), book2.getId(), 4);
        orderService.createOrder(member9.getId(), book.getId(), 5);
        orderService.createOrder(member10.getId(), book2.getId(), 8);
        
        
        category.addItem(book);
        category.addItem(book2);
        
        category1.addItem(book);
        category2.addItem(book2);
        category3.addItem(book2);


    	categoryRepository.save(category);
    	categoryRepository.save(category1);
    	categoryRepository.save(category2);
    	categoryRepository.save(category3);
        itemRepository.save(book);
        itemRepository.save(book2);    	
    }


    private Book createBook(String name, int price, int stockQuantity) {
        Book book = new Book();
        book.setName(name);
        book.setPrice(price);
        book.setStockQuantity(stockQuantity);
        return book;
    }

}
