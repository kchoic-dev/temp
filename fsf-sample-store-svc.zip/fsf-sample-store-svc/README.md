# __5s Framework Sample Service__
5s Framework [__인증 서비스__][]와 연동하는 5s Framework의 비즈니스 마이크로 서비스의 최소한의 기능과 예제가 구현된 마이크로 서비스 입니다.
![마이크로 서비스 그림](docs/images/micro_service_component_view_biz_flickering.gif)

##### __목차__
1. [Application 설정](#5s1)
    1. [OAuth 설정](#5s1-1)
    2. [DB Schema 초기 설정](#5s1-2)
    3. [DB 연결 설정](#5s1-3) 
2. [샘플 마이크로 서비스 기능](#5s2)
    1. [REST API 목록](#5s2-1)

## <a id="5s1"/>__Application 설정__
### <a id="5s1-1"/>__OAuth 설정__

renoteTokenService 설정

[/src/main/resources/config/application.yml](http://70.121.244.190/gitnsam/fsframework/fsf-sample-store-svc/blob/master/src/main/resources/config/application.yml#L3-5)
```
auth:
    server:
        url: http://70.7.41.189/fsf/auth/oauth/check_token
        clientId: fsfDefault
        clientsecret: fsfDefaultSecret
```


### <a id="5s1-2"/>__DB Schema 초기 설정__ 

Hibernate `hibernate.hbm2ddl.auto` property 사용
[src/main/resources/config/application-dev.yml](http://70.121.244.190/gitnsam/fsframework/fsf-sample-store-svc/blob/master/src/main/resources/config/application-dev.yml#L23)
최초 DB Schema 생성시

```
        hibernate:
            ddl-auto: create
```

이후  DB Schema 검증시

```
        hibernate:
            ddl-auto: validate
```



### <a id="5s1-3"/>__DB 연결 설정__
[/src/main/resources/config/application-dev.yml](http://70.121.244.190/gitnsam/fsframework/fsf-sample-store-svc/blob/master/src/main/resources/config/application-dev.yml#L8-14)
```
    datasource:
        dataSourceClassName: org.postgresql.ds.PGSimpleDataSource
        url: jdbc:postgresql://70.7.41.188:5442/sample
        databaseName: sample
        serverName: 70.7.41.188
        username: fsfsample
        password: fsfsample
    }
```


## <a id="5s2"/>__샘플 마이크로 서비스 기능__
도서(book)와 작가(author) 정보를 입력, 열람, 수정, 삭제하는 기능

Logical Model
![Logical Model](docs/model/LDM.png)

Physical Model
![Physical Model](docs/model/PDM.png)

### <a id="5s2-1"/>__REST API 목록__
![REST API 목록 그림](docs/images/API.PNG)


## <a id="5s3"/>__기동__

### __간편기동__

Spring-Boot 를 이용하여 기동

    mvn spring-boot:run

spring.profiles.active=boot 가 적용되며

H2 DB에 스키마 생성하면서 기동됨

Context Root는 /fsf/sample/store


### __개발환경 기동__

Eclipse의 tomcat 등에 배포하여 기동

spring.profiles.active=dev 가 적용되며

DB 연결성정 정보를 변경하여야 함


[__인증 서비스__]: http://70.121.244.190/gitnsam/fsframework/fsf-auth-svc/tree/master 